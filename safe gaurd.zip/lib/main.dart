import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';

import 'screens/report_harassment.dart';
import 'screens/phishing_screen.dart';
import 'screens/analytics_screen.dart';
import 'screens/my_cases_screen.dart';

void main() {
  runApp(const SafeGaurdApp());
}

class SafeGaurdApp extends StatelessWidget {
  const SafeGaurdApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Safe Gaurd',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.pink),
      ),
      home: const SOSHomeScreen(),
    );
  }
}

class SOSHomeScreen extends StatefulWidget {
  const SOSHomeScreen({super.key});

  @override
  State<SOSHomeScreen> createState() => _SOSHomeScreenState();
}

class _SOSHomeScreenState extends State<SOSHomeScreen> {

  static const MethodChannel smsChannel =
      MethodChannel('sms_channel');

  static const MethodChannel sosChannel =
      MethodChannel('sos_channel');

  @override
  void initState() {
    super.initState();

    sosChannel.setMethodCallHandler((call) async {
      if (call.method == "triggerSOS") {
        await triggerSOS();
      }
    });
  }

  Future<void> triggerSOS() async {
    try {
      await [
        Permission.location,
        Permission.sms,
      ].request();

      if (!await Permission.location.isGranted ||
          !await Permission.sms.isGranted) {
        return;
      }

      Position position =
          await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      String googleMapsLink =
          "https://www.google.com/maps?q=${position.latitude},${position.longitude}";

      String message =
          "🚨 EMERGENCY ALERT!\n\n"
          "I am in danger. Please help immediately.\n\n"
          "📍 Live Location:\n$googleMapsLink\n\n"
          "Sent via Safe Gaurd App";

      await smsChannel.invokeMethod('sendSMS', {
        "phone": "+91 7639264381", 
        "message": message,
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("🚨 SOS Alert Sent Successfully"),
            backgroundColor: Colors.red,
          ),
        );
      }

    } catch (e) {
      debugPrint("SOS Error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.grey.shade100,
      appBar: AppBar(
        title: const Text("Safe Gaurd"),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: ListView(
          children: [

            const SizedBox(height: 10),

            // 🚨 SOS CARD
            Card(
              elevation: 6,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
              child: Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  gradient: const LinearGradient(
                    colors: [Colors.red, Colors.pink],
                  ),
                ),
                child: Column(
                  children: [
                    const Icon(Icons.warning,
                        size: 50, color: Colors.white),
                    const SizedBox(height: 10),
                    const Text(
                      "Emergency SOS",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 15),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: Colors.red,
                      ),
                      onPressed: triggerSOS,
                      child: const Text("SEND ALERT"),
                    )
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),

            buildNavigationCard(
              icon: Icons.campaign,
              color: Colors.pink,
              title: "Report Harassment",
              subtitle: "Submit anonymous complaint",
              screen: const ReportHarassmentScreen(),
            ),

            buildNavigationCard(
              icon: Icons.security,
              color: Colors.purple,
              title: "AI Phishing Detection",
              subtitle: "Analyze suspicious links",
              screen: PhishingScreen(),
            ),

            buildNavigationCard(
              icon: Icons.bar_chart,
              color: Colors.blue,
              title: "Threat Analytics",
              subtitle: "View safety statistics",
              screen: AnalyticsScreen(),
            ),

            buildNavigationCard(
              icon: Icons.folder,
              color: Colors.teal,
              title: "My Cases",
              subtitle: "Track your anonymous reports",
              screen: MyCasesScreen(),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildNavigationCard({
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    required Widget screen,
  }) {
    return Card(
      elevation: 5,
      margin: const EdgeInsets.symmetric(vertical: 8),
      shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      child: ListTile(
        leading: Icon(icon, color: color),
        title: Text(title),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.arrow_forward_ios),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => screen),
          );
        },
      ),
    );
  }
}