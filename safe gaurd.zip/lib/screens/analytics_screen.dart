import 'package:flutter/material.dart';

class AnalyticsScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    int totalReports = 42;
    int highRisk = 18;
    int mediumRisk = 14;
    int lowRisk = 10;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Threat Analytics"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [

            buildStatCard("Total Reports", totalReports.toString(), Colors.blue),
            buildStatCard("High Risk Cases", highRisk.toString(), Colors.red),
            buildStatCard("Medium Risk Cases", mediumRisk.toString(), Colors.orange),
            buildStatCard("Low Risk Cases", lowRisk.toString(), Colors.green),

          ],
        ),
      ),
    );
  }

  Widget buildStatCard(String title, String value, Color color) {
    return Card(
      elevation: 6,
      margin: const EdgeInsets.symmetric(vertical: 10),
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20)),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(
            colors: [color.withOpacity(0.7), color],
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(title,
                style: const TextStyle(
                    fontSize: 18,
                    color: Colors.white,
                    fontWeight: FontWeight.bold)),
            Text(value,
                style: const TextStyle(
                    fontSize: 22,
                    color: Colors.white,
                    fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}