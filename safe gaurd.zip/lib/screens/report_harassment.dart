import 'package:flutter/material.dart';
import 'package:record/record.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'dart:math';

class ReportHarassmentScreen extends StatefulWidget {
  const ReportHarassmentScreen({super.key});

  @override
  State<ReportHarassmentScreen> createState() =>
      _ReportHarassmentScreenState();
}

class _ReportHarassmentScreenState
    extends State<ReportHarassmentScreen> {
  final TextEditingController _controller =
      TextEditingController();

  final AudioRecorder _recorder = AudioRecorder();
  final AudioPlayer _player = AudioPlayer();

  bool isRecording = false;
  String? audioPath;

  static List<Map<String, dynamic>> myCases = [];

  // 🔐 Generate Anonymous Case ID
  String generateCaseId() {
    final random = Random();
    return "CASE-${1000 + random.nextInt(9000)}";
  }

  // 🎙 START RECORDING
  Future<void> startRecording() async {
    try {
      bool hasPermission = await _recorder.hasPermission();

      if (!hasPermission) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text("Microphone permission denied")),
        );
        return;
      }

      final directory =
          await getApplicationDocumentsDirectory();

      audioPath =
          '${directory.path}/audio_${DateTime.now().millisecondsSinceEpoch}.m4a';

      await _recorder.start(
        const RecordConfig(
          encoder: AudioEncoder.aacLc,
          bitRate: 128000,
          sampleRate: 44100,
        ),
        path: audioPath!,
      );

      setState(() => isRecording = true);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Recording started...")),
      );
    } catch (e) {
      debugPrint("Recording error: $e");
    }
  }

  // ⏹ STOP RECORDING
  Future<void> stopRecording() async {
    try {
      await _recorder.stop();
      setState(() => isRecording = false);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Recording saved")),
      );
    } catch (e) {
      debugPrint("Stop error: $e");
    }
  }

  // ▶ PLAY RECORDING
  Future<void> playRecording() async {
    try {
      if (audioPath != null &&
          File(audioPath!).existsSync()) {
        await _player.play(DeviceFileSource(audioPath!));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text("No recording found")),
        );
      }
    } catch (e) {
      debugPrint("Playback error: $e");
    }
    print("Saved at: $audioPath");
  }

  // 🚀 SUBMIT REPORT
  void submitReport() {
    if (_controller.text.isEmpty &&
        audioPath == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
              "Please write or record your report"),
        ),
      );
      return;
    }

    String caseId = generateCaseId();

    myCases.add({
      "id": caseId,
      "text": _controller.text,
      "audio": audioPath,
      "status": "Submitted",
      "timestamp": DateTime.now(),
    });

    _controller.clear();
    audioPath = null;

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Report Submitted"),
        content: Text(
          "Your Case ID: $caseId\n\n"
          "Your identity is completely anonymous.\n\n"
          "A verified mental health advisor will review your case.",
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _recorder.dispose();
    _player.dispose();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Anonymous Harassment Report"),
        backgroundColor: Colors.pink,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Text(
              "Share your experience safely and anonymously.\nNo personal data is collected.",
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 20),

            // 📝 TEXT FIELD
            Expanded(
              child: TextField(
                controller: _controller,
                maxLines: null,
                expands: true,
                decoration: const InputDecoration(
                  labelText: "Describe your incident",
                  border: OutlineInputBorder(),
                ),
              ),
            ),

            const SizedBox(height: 15),

            // 🎙 AUDIO BUTTONS
            Row(
              mainAxisAlignment:
                  MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton.icon(
                  icon: Icon(isRecording
                      ? Icons.stop
                      : Icons.mic),
                  label: Text(
                      isRecording ? "Stop" : "Record"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: isRecording
                        ? Colors.red
                        : Colors.pink,
                  ),
                  onPressed: () async {
                    if (isRecording) {
                      await stopRecording();
                    } else {
                      await startRecording();
                    }
                  },
                ),
                ElevatedButton.icon(
                  icon: const Icon(Icons.play_arrow),
                  label: const Text("Play"),
                  onPressed: playRecording,
                ),
              ],
            ),

            const SizedBox(height: 20),

            // 🚀 SUBMIT BUTTON
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.pink,
                minimumSize:
                    const Size(double.infinity, 55),
              ),
              onPressed: submitReport,
              child: const Text(
                "Submit Anonymously",
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}