import 'package:flutter/material.dart';

class CaseModel {
  final String caseId;
  final String type;
  final String severity;
  final String message;
  final String status;
  final String advisorReply;

  CaseModel({
    required this.caseId,
    required this.type,
    required this.severity,
    required this.message,
    required this.status,
    required this.advisorReply,
  });
}

class MyCasesScreen extends StatefulWidget {
  static List<CaseModel> cases = [];

  @override
  State<MyCasesScreen> createState() => _MyCasesScreenState();
}

class _MyCasesScreenState extends State<MyCasesScreen> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Anonymous Cases"),
      ),
      body: MyCasesScreen.cases.isEmpty
          ? const Center(
              child: Text(
                "No reports submitted yet.",
                style: TextStyle(fontSize: 16),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(15),
              itemCount: MyCasesScreen.cases.length,
              itemBuilder: (context, index) {
                final caseItem = MyCasesScreen.cases[index];

                return Card(
                  elevation: 6,
                  margin: const EdgeInsets.symmetric(vertical: 10),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15)),
                  child: Padding(
                    padding: const EdgeInsets.all(15),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [

                        Text(
                          "Case ID: ${caseItem.caseId}",
                          style: const TextStyle(
                              fontWeight: FontWeight.bold),
                        ),

                        const SizedBox(height: 8),

                        Text("Type: ${caseItem.type}"),
                        Text("Severity: ${caseItem.severity}"),

                        const SizedBox(height: 8),

                        Text(
                          "Status: ${caseItem.status}",
                          style: TextStyle(
                            color: caseItem.status == "Resolved"
                                ? Colors.green
                                : Colors.orange,
                          ),
                        ),

                        const Divider(height: 20),

                        const Text(
                          "Advisor Response:",
                          style: TextStyle(
                              fontWeight: FontWeight.bold),
                        ),

                        const SizedBox(height: 5),

                        Text(caseItem.advisorReply),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}