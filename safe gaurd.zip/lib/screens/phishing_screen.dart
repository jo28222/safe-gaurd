import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:math';

class PhishingScreen extends StatefulWidget {
  const PhishingScreen({super.key});

  @override
  _PhishingScreenState createState() => _PhishingScreenState();
}

class _PhishingScreenState extends State<PhishingScreen> {
  final TextEditingController _inputController = TextEditingController();

  // Initializing with default values
  String riskLevel = "";
  String threatType = "";
  double riskScore = 0;
  double confidence = 0;
  Color riskColor = Colors.black;
  String caseId = "";

  static const MethodChannel smsChannel = MethodChannel('sms_channel');

  @override
  void dispose() {
    _inputController.dispose(); // CRITICAL: Prevent memory leaks
    super.dispose();
  }

  void analyzeMessage() {
    String text = _inputController.text.toLowerCase().trim();
    if (text.isEmpty) return;

    int score = 0;
    
    // Scrutiny Logic
    if (text.contains("urgent") || text.contains("immediately")) score += 15;
    if (text.contains("bank") || text.contains("otp") || text.contains("password")) score += 25;
    if (text.contains("lottery") || text.contains("win") || text.contains("prize")) score += 20;
    if (text.contains("http")) score += 25;
    if (text.contains(".xyz") || text.contains(".ru") || text.contains(".bit")) score += 15;

    setState(() {
      riskScore = min(score.toDouble(), 100);
      caseId = "SG-${DateTime.now().millisecondsSinceEpoch}";

      if (riskScore >= 70) {
        riskLevel = "🔴 HIGH RISK";
        riskColor = Colors.red;
        threatType = "Dangerous Phishing Attempt";
      } else if (riskScore >= 40) {
        riskLevel = "🟡 MEDIUM RISK";
        riskColor = Colors.orange;
        threatType = "Suspicious Communication";
      } else {
        riskLevel = "🟢 LOW RISK";
        riskColor = Colors.green;
        threatType = "Likely Safe";
      }

      // Confidence capping at 100%
      confidence = min((riskScore * 0.8) + Random().nextInt(20), 100.0);
    });

    if (riskScore >= 70) {
      // Delay slightly to ensure UI has updated before dialog pops
      Future.delayed(Duration.zero, () => showHighRiskDialog());
    }
  }

  void showHighRiskDialog() {
    if (!mounted) return; // Check if screen is still active
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("🚨 HIGH RISK DETECTED"),
        content: const Text("This looks like a scam. Would you like to report this to Cyber Authorities?"),
        actions: [
          TextButton(
            child: const Text("Ignore"),
            onPressed: () => Navigator.pop(context),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              sendReport();
            },
            child: const Text("Report Now"),
          ),
        ],
      ),
    );
  }

  Future<void> sendReport() async {
    try {
      String message = "🛡 SAFE GUARD - PHISHING REPORT\n"
          "Case: $caseId\n"
          "Score: $riskScore%\n"
          "Type: $threatType\n\n"
          "Content: ${_inputController.text}";

      await smsChannel.invokeMethod('sendSMS', {
        "phone": "+91 7639264381",
        "message": message,
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Case $caseId Reported"), backgroundColor: Colors.green),
        );
      }
    } catch (e) {
      debugPrint("SMS Error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("AI Phishing Detector"), backgroundColor: Colors.pink),
      // Use a ListView to prevent keyboard overflow errors
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text("Paste suspicious message:", style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          TextField(
            controller: _inputController,
            maxLines: 5,
            decoration: const InputDecoration(
              hintText: "Enter SMS or Email text...",
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 15),
          ElevatedButton(
            style: ElevatedButton.styleFrom(minimumSize: const Size(double.infinity, 50)),
            onPressed: analyzeMessage,
            child: const Text("Analyze with AI"),
          ),
          const SizedBox(height: 20),
          if (riskLevel.isNotEmpty) ...[
            Card(
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Text(riskLevel, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: riskColor)),
                    const Divider(),
                    Text("Risk Score: ${riskScore.toInt()}%"),
                    Text("Threat: $threatType"),
                    Text("AI Confidence: ${confidence.toStringAsFixed(1)}%"),
                    Text("ID: $caseId", style: const TextStyle(fontSize: 10, color: Colors.grey)),
                  ],
                ),
              ),
            ),
            if (riskScore >= 40) ...[
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: sendReport,
                icon: const Icon(Icons.report_problem, color: Colors.orange),
                label: const Text("Report to Authorities"),
              ),
            ]
          ]
        ],
      ),
    );
  }
}