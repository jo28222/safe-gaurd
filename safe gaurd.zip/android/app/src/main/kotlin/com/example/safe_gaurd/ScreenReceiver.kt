package com.example.safe_gaurd

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import io.flutter.embedding.engine.FlutterEngineCache
import io.flutter.plugin.common.MethodChannel

class ScreenReceiver : BroadcastReceiver() {

    private var pressCount = 0
    private val handler = Handler(Looper.getMainLooper())

    override fun onReceive(context: Context?, intent: Intent?) {

        if (intent?.action == Intent.ACTION_SCREEN_ON ||
            intent?.action == Intent.ACTION_SCREEN_OFF) {

            pressCount++

            if (pressCount >= 3) {
                triggerSOS()
                pressCount = 0
            }

            handler.postDelayed({
                pressCount = 0
            }, 5000)
        }
    }

    private fun triggerSOS() {
        val engine = FlutterEngineCache.getInstance().get("my_engine_id")
        engine?.dartExecutor?.binaryMessenger?.let {
            MethodChannel(it, "sos_channel").invokeMethod("triggerSOS", null)
        }
    }
}