package com.example.safe_gaurd

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.os.Handler
import android.os.Looper
import io.flutter.plugin.common.MethodChannel
import io.flutter.embedding.engine.FlutterEngineCache

class PowerButtonService : AccessibilityService() {

    private var pressCount = 0
    private val handler = Handler(Looper.getMainLooper())

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {

        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {

            pressCount++

            if (pressCount >= 3) {
                triggerFlutterSOS()
                pressCount = 0
            }

            handler.postDelayed({
                pressCount = 0
            }, 3000)
        }
    }

    private fun triggerFlutterSOS() {

        val engine = FlutterEngineCache.getInstance().get("my_engine_id")
        engine?.dartExecutor?.binaryMessenger?.let {
            MethodChannel(it, "sos_channel").invokeMethod("triggerSOS", null)
        }
    }

    override fun onInterrupt() {}
}