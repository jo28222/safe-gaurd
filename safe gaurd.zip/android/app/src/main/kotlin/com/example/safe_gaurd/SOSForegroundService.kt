package com.example.safe_gaurd

import android.app.*
import android.content.*
import android.os.*
import androidx.core.app.NotificationCompat
import io.flutter.embedding.engine.FlutterEngineCache
import io.flutter.plugin.common.MethodChannel

class SOSForegroundService : Service() {

    private var pressCount = 0
    private val handler = Handler(Looper.getMainLooper())

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {

            if (intent?.action == Intent.ACTION_SCREEN_ON ||
                intent?.action == Intent.ACTION_SCREEN_OFF) {

                pressCount++

                if (pressCount >= 3) {
                    triggerSOS()
                    pressCount = 0
                }

                handler.postDelayed({
                    pressCount = 0
                }, 5000)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()

        registerReceiver(screenReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        })

        startForegroundService()
    }

    private fun startForegroundService() {

        val channelId = "SOSServiceChannel"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "SOS Background Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Safe Gaurd Active")
            .setContentText("Emergency detection running")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .build()

        startForeground(1, notification)
    }

    private fun triggerSOS() {
        val engine = FlutterEngineCache.getInstance().get("my_engine_id")
        engine?.dartExecutor?.binaryMessenger?.let {
            MethodChannel(it, "sos_channel").invokeMethod("triggerSOS", null)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}