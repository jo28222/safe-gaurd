package com.example.safe_gaurd

import android.content.Intent
import android.net.Uri
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.engine.FlutterEngineCache
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {

    private val SMS_CHANNEL = "sms_channel"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        // 🔥 Cache Flutter engine (needed for SOS trigger)
        FlutterEngineCache
            .getInstance()
            .put("my_engine_id", flutterEngine)

        // 🚨 Start Foreground SOS Service
        val serviceIntent = Intent(this, SOSForegroundService::class.java)
        startForegroundService(serviceIntent)

        // 📩 SMS Channel (opens SMS app with message)
        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            SMS_CHANNEL
        ).setMethodCallHandler { call, result ->

            if (call.method == "sendSMS") {

                val phone = call.argument<String>("phone")
                val message = call.argument<String>("message")

                val intent = Intent(Intent.ACTION_SENDTO)
                intent.data = Uri.parse("smsto:$phone")
                intent.putExtra("sms_body", message)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK

                startActivity(intent)

                result.success("SMS App Opened")
            }
        }
    }
}